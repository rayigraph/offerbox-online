function quiz(){
    class question{
        
    }
    function next(){
        qnum=qnum+1;
    }
    function previous(){
        qnum=qnum-1;
    }
    function submit(){
    }
    function question()
    {

    }
    var qnum;
    var options[4];


}
class ClassName {
  constructor() { ... }
}