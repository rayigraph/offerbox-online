<?php
$sql = "INSERT INTO users (score) VALUE (32)";
?>