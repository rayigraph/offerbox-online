var _0x1e05=[' /><label for=\x27checkbox','value','Explanation: ','explanation','Quiz','score','currentQuestion','object','hasOwnProperty','elementId','questionContainer','question-container','submitPrnt','button','submitButton','Submit','addEventListener','click','bind','showAllQuestions','setAttribute','display: none;','nextButton','Next','style','display: block;','showTimer','timer','00:00:00','setSeconds','substr','getElementById','myLink','fontSize','textAlign','center','lastChild','remove','disabled','checked','right','incorrect','correct','timerInterval','Your Score: ','createElement','div','className','question','span','questionNum','innerHTML','appendChild','questionName','options','quizQuestions','getElementsByClassName','single-question-container','radio','type','length','call','checkbox','option','<input type=\x27radio\x27 id=\x27radio','\x27 name=\x27radio','\x27 value=',' /><label for=\x27radio','</label>','\x27 name=\x27checkbox'];
(function(_0x4bffaa,_0xaaefc5)
{
  var _0x1025a5=function(_0x3bdce3)
  {
    while(--_0x3bdce3)
    {
      _0x4bffaa['push'](_0x4bffaa['shift']());}};_0x1025a5(++_0xaaefc5);}(_0x1e05,0xb9));
      var _0x5730=function(_0x2c9e9d,_0x51e73f)
      {
        _0x2c9e9d=_0x2c9e9d-0x0;
        var _0x462ef3=_0x1e05[_0x2c9e9d];
        return _0x462ef3;
      };
      (function()
        {
          function _0x167a84(_0x2e5740)
          {
            var _0x364c2a=document[_0x5730('0x0')](_0x5730('0x1'));
            _0x364c2a[_0x5730('0x2')]=_0x5730('0x3');
var _0x5a497d=document['createElement'](_0x5730('0x4'));
_0x5a497d[_0x5730('0x2')]=_0x5730('0x5'),_0x5a497d[_0x5730('0x6')]=_0x2e5740+0x1+'.',_0x364c2a[_0x5730('0x7')](_0x5a497d);
var _0x167a84=document[_0x5730('0x0')](_0x5730('0x1'));
if(_0x167a84['className']=_0x5730('0x8'),_0x167a84[_0x5730('0x6')]=this[_0x5730('0x9')][_0x5730('0xa')][_0x2e5740][_0x5730('0x3')],_0x364c2a[_0x5730('0x7')](_0x167a84),document[_0x5730('0xb')](_0x5730('0xc')+_0x2e5740)[0x0][_0x5730('0x7')](_0x364c2a),_0x5730('0xd')==this[_0x5730('0x9')][_0x5730('0xa')][_0x2e5740][_0x5730('0xe')])for(
  var _0x5611e8=0x0;_0x5611e8<this[_0x5730('0x9')][_0x5730('0xa')][_0x2e5740][_0x5730('0x9')][_0x5730('0xf')];_0x5611e8++)_0x2dc66d[_0x5730('0x10')](this,_0x2e5740,_0x5611e8);else if(_0x5730('0x11')==this[_0x5730('0x9')][_0x5730('0xa')][_0x2e5740][_0x5730('0xe')])for(_0x5611e8=0x0;_0x5611e8<this[_0x5730('0x9')][_0x5730('0xa')][_0x2e5740]['options'][_0x5730('0xf')];_0x5611e8++)_0x153258[_0x5730('0x10')](this,_0x2e5740,_0x5611e8);}function _0x2dc66d(_0x3c08d6,_0x8d4f63)
  {
  var _0x60ee72=document[_0x5730('0x0')](_0x5730('0x1'));_0x60ee72['className']=_0x5730('0x12');
var _0x167a84=_0x5730('0x13')+_0x3c08d6+_0x8d4f63+_0x5730('0x14')+_0x3c08d6+_0x5730('0x15')+_0x8d4f63+_0x5730('0x16')+_0x3c08d6+_0x8d4f63+_0x5730('0x14')+_0x3c08d6+'\x27>'+data[_0x3c08d6][_0x5730('0x9')][_0x8d4f63]['value']+_0x5730('0x17');_0x60ee72[_0x5730('0x6')]=_0x167a84,document[_0x5730('0xb')](_0x5730('0xc')+_0x3c08d6)[0x0][_0x5730('0x7')](_0x60ee72);}function _0x153258(_0x3c7705,_0x2d756e)
{
  var _0x5d75a4=document['createElement'](_0x5730('0x1'));_0x5d75a4[_0x5730('0x2')]=_0x5730('0x12');  
var _0x167a84='<input type=\x27checkbox\x27 id=\x27checkbox'+_0x3c7705+_0x2d756e+_0x5730('0x18')+_0x3c7705+_0x5730('0x15')+_0x2d756e+_0x5730('0x19')+_0x3c7705+_0x2d756e+_0x5730('0x18')+_0x3c7705+'\x27>'+data[_0x3c7705][_0x5730('0x9')][_0x2d756e][_0x5730('0x1a')]+'</label>';_0x5d75a4[_0x5730('0x6')]=_0x167a84,document[_0x5730('0xb')](_0x5730('0xc')+_0x3c7705)[0x0][_0x5730('0x7')](_0x5d75a4);}function _0x67946b(_0x119fd1)
{
  if(''!=this[_0x5730('0x9')][_0x5730('0xa')][_0x119fd1]['explanation'])
{
      var _0x2b1682=document[_0x5730('0x0')](_0x5730('0x1'));_0x2b1682['innerHTML']=_0x5730('0x1b')+this['options'][_0x5730('0xa')][_0x119fd1][_0x5730('0x1c')],document[_0x5730('0xb')](_0x5730('0xc')+_0x119fd1)[0x0][_0x5730('0x7')](_0x2b1682);}}this[_0x5730('0x1d')]=function()
    {
      this[_0x5730('0x1e')]=0x0;arguments[this[_0x5730('0x1f')]=0x0]&&_0x5730('0x20')==typeof arguments[0x0]&&(this[_0x5730('0x9')]=function(_0x341a96,_0x27938b)
    {

    var _0x5977e5;for(_0x5977e5 in _0x27938b)_0x27938b[_0x5730('0x21')](_0x5977e5)&&(_0x341a96[_0x5977e5]=_0x27938b[_0x5977e5]);return _0x341a96;}(
      {
        'quizQuestions':
    {

    },'elementId':'','showAllQuestions':!0x0,'showTimer':!0x0},arguments[0x0])),function()
    {

    var _0x32d1c7=document['getElementById'](this['options'][_0x5730('0x22')]);this[_0x5730('0x23')]=document[_0x5730('0x0')]('div'),this[_0x5730('0x23')][_0x5730('0x2')]=_0x5730('0x24'),_0x32d1c7[_0x5730('0x7')](this['questionContainer']);for(
    var _0x102230=0x0;_0x102230<this[_0x5730('0x9')][_0x5730('0xa')][_0x5730('0xf')];_0x102230++)
    {

    var _0x508e9d=document[_0x5730('0x0')](_0x5730('0x1'));_0x508e9d[_0x5730('0x2')]='single-question-container single-question-container'+_0x102230,this[_0x5730('0x23')][_0x5730('0x7')](_0x508e9d),_0x167a84[_0x5730('0x10')](this,_0x102230);}(function()
    {
      this[_0x5730('0x25')]=document[_0x5730('0x0')](_0x5730('0x1')),this[_0x5730('0x25')]['className']='submitPrnt',this['submitButton']=document[_0x5730('0x0')](_0x5730('0x26')),this[_0x5730('0x27')][_0x5730('0x2')]='submit-button',this[_0x5730('0x27')]['innerHTML']=_0x5730('0x28'),this[_0x5730('0x25')]['appendChild'](this[_0x5730('0x27')]),this[_0x5730('0x23')][_0x5730('0x7')](this[_0x5730('0x25')]),this['submitButton'][_0x5730('0x29')](_0x5730('0x2a'),onSubmitQuiz[_0x5730('0x2b')](this));}[_0x5730('0x10')](this),function()
    {
      if(!this[_0x5730('0x9')][_0x5730('0x2c')])
    {

    var _0x32d1c7=document[_0x5730('0xb')](_0x5730('0xc'));for(
    var _0x102230 in _0x32d1c7)_0x32d1c7[_0x5730('0x21')](_0x102230)&&_0x102230!=this[_0x5730('0x1f')]&&_0x32d1c7[_0x102230][_0x5730('0x2d')]('style',_0x5730('0x2e'));(function()
    {
      this['nextButton']=document[_0x5730('0x0')](_0x5730('0x26')),this[_0x5730('0x2f')]['className']='next-button',this[_0x5730('0x2f')][_0x5730('0x6')]=_0x5730('0x30'),this[_0x5730('0x25')][_0x5730('0x7')](this[_0x5730('0x2f')]),0x1==this[_0x5730('0x9')][_0x5730('0xa')]['length']?(this[_0x5730('0x2f')][_0x5730('0x2d')](_0x5730('0x31'),_0x5730('0x2e')),this[_0x5730('0x27')][_0x5730('0x2d')](_0x5730('0x31'),_0x5730('0x32'))):this[_0x5730('0x27')][_0x5730('0x2d')]('style','display: none;');this[_0x5730('0x2f')]['addEventListener'](_0x5730('0x2a'),onNextButton[_0x5730('0x2b')](this));}['call'](this));}}[_0x5730('0x10')](this),function()
    {
      if(this[_0x5730('0x9')][_0x5730('0x33')])
    {

    var _0x508e9d=document[_0x5730('0x0')](_0x5730('0x4'));_0x508e9d[_0x5730('0x2')]=_0x5730('0x34'),_0x508e9d['innerHTML']=_0x5730('0x35'),this[_0x5730('0x25')][_0x5730('0x7')](_0x508e9d);
  var _0x167a84=0x0;this['timerInterval']=setInterval(function()
  {
    _0x167a84++;
    var _0x32d1c7=new Date(null);_0x32d1c7[_0x5730('0x36')](_0x167a84);
  var _0x102230=_0x32d1c7['toISOString']()[_0x5730('0x37')](0xb,0x8);_0x508e9d[_0x5730('0x6')]=_0x102230;},0x3e8);}}[_0x5730('0x10')](this),function()
  {

    var _0x32d1c7=document[_0x5730('0x38')](this[_0x5730('0x9')][_0x5730('0x22')]);this[_0x5730('0x39')]=document[_0x5730('0x0')]('div'),this[_0x5730('0x39')]['style'][_0x5730('0x3a')]='90%',this[_0x5730('0x39')][_0x5730('0x31')][_0x5730('0x3b')]=_0x5730('0x3c'),this[_0x5730('0x39')][_0x5730('0x6')]='This quiz has been created using the tool <a target=\x27_blank\x27 href=\x27https://www.htmlcodegenerator-tools.com/2019/10/html-javascript-quiz-generator-score-timer.html\x27>HTML Quiz Generator</a>',_0x32d1c7['appendChild'](this[_0x5730('0x39')]);}['call'](this),function()
    {

    var _0x32d1c7=document[_0x5730('0x38')](this[_0x5730('0x9')][_0x5730('0x22')]);_0x32d1c7[_0x5730('0x3d')]['innerHTML'][_0x5730('0xf')]<=0xc8&&0xb4<=_0x32d1c7[_0x5730('0x3d')][_0x5730('0x6')]['length']||_0x32d1c7[_0x5730('0x3e')]();}[_0x5730('0x10')](this));}[_0x5730('0x10')](this);},onNextButton=function()
    {
      this['currentQuestion']++;
  var _0x30aa9a=document[_0x5730('0xb')](_0x5730('0xc'));
  for(var _0xb4dd3b in _0x30aa9a)_0x30aa9a['hasOwnProperty'](_0xb4dd3b)&&(_0x30aa9a[_0xb4dd3b]['setAttribute']('style',_0x5730('0x2e')),_0xb4dd3b==this[_0x5730('0x1f')]&&_0x30aa9a[_0xb4dd3b][_0x5730('0x2d')](_0x5730('0x31'),_0x5730('0x32')));this[_0x5730('0x1f')]==this[_0x5730('0x9')][_0x5730('0xa')][_0x5730('0xf')]-0x1&&(this[_0x5730('0x27')][_0x5730('0x2d')](_0x5730('0x31'),_0x5730('0x32')),this[_0x5730('0x2f')][_0x5730('0x2d')](_0x5730('0x31'),_0x5730('0x2e')));},onSubmitQuiz=function()
    {
      document[_0x5730('0x38')](this[_0x5730('0x9')][_0x5730('0x22')]);this['submitButton'][_0x5730('0x2d')](_0x5730('0x31'),_0x5730('0x2e'));
  var _0x3bbba0=document[_0x5730('0xb')](_0x5730('0xc'));
  for(
    var _0x5edfb1 in _0x3bbba0)_0x3bbba0[_0x5730('0x21')](_0x5edfb1)&&_0x3bbba0[_0x5edfb1][_0x5730('0x2d')](_0x5730('0x31'),'display: block;');
    for(
    var _0x1b9f10=0x0;_0x1b9f10<this[_0x5730('0x9')][_0x5730('0xa')][_0x5730('0xf')];_0x1b9f10++)
    {
      if(_0x5730('0xd')==this[_0x5730('0x9')][_0x5730('0xa')][_0x1b9f10]['type'])
      for(_0x5edfb1=0x0;_0x5edfb1<this[_0x5730('0x9')][_0x5730('0xa')][_0x1b9f10][_0x5730('0x9')][_0x5730('0xf')];_0x5edfb1++)document[_0x5730('0x38')](_0x5730('0xd')+_0x1b9f10+_0x5edfb1)[_0x5730('0x3f')]=!0x0,document[_0x5730('0x38')](_0x5730('0xd')+_0x1b9f10+_0x5edfb1)[_0x5730('0x40')]&&!this[_0x5730('0x9')][_0x5730('0xa')][_0x1b9f10][_0x5730('0x9')][_0x5edfb1][_0x5730('0x41')]?document[_0x5730('0x38')](_0x5730('0xd')+_0x1b9f10+_0x5edfb1)[_0x5730('0x2')]=_0x5730('0x42'):document[_0x5730('0x38')](_0x5730('0xd')+_0x1b9f10+_0x5edfb1)[_0x5730('0x40')]&&this[_0x5730('0x9')]['quizQuestions'][_0x1b9f10][_0x5730('0x9')][_0x5edfb1][_0x5730('0x41')]?(document[_0x5730('0x38')](_0x5730('0xd')+_0x1b9f10+_0x5edfb1)[_0x5730('0x2')]=_0x5730('0x43'),this[_0x5730('0x1e')]++):!document['getElementById'](_0x5730('0xd')+_0x1b9f10+_0x5edfb1)[_0x5730('0x40')]&&this['options']['quizQuestions'][_0x1b9f10][_0x5730('0x9')][_0x5edfb1][_0x5730('0x41')]&&(document[_0x5730('0x38')](_0x5730('0xd')+_0x1b9f10+_0x5edfb1)[_0x5730('0x2')]=_0x5730('0x43'));
      else if(_0x5730('0x11')==this['options'][_0x5730('0xa')][_0x1b9f10][_0x5730('0xe')])
    {

    var _0x167a84=!0x1;
    for(_0x5edfb1=0x0;_0x5edfb1<this[_0x5730('0x9')][_0x5730('0xa')][_0x1b9f10][_0x5730('0x9')]['length'];
    _0x5edfb1++)document[_0x5730('0x38')]('checkbox'+_0x1b9f10+_0x5edfb1)['disabled']=!0x0,document[_0x5730('0x38')]('checkbox'+_0x1b9f10+_0x5edfb1)[_0x5730('0x40')]&&!this[_0x5730('0x9')][_0x5730('0xa')][_0x1b9f10][_0x5730('0x9')][_0x5edfb1][_0x5730('0x41')]?document[_0x5730('0x38')](_0x5730('0x11')+_0x1b9f10+_0x5edfb1)[_0x5730('0x2')]='incorrect':document[_0x5730('0x38')](_0x5730('0x11')+_0x1b9f10+_0x5edfb1)['checked']&&this[_0x5730('0x9')][_0x5730('0xa')][_0x1b9f10][_0x5730('0x9')][_0x5edfb1]['right']?document['getElementById']('checkbox'+_0x1b9f10+_0x5edfb1)[_0x5730('0x2')]=_0x5730('0x43'):!document[_0x5730('0x38')]('checkbox'+_0x1b9f10+_0x5edfb1)[_0x5730('0x40')]&&this[_0x5730('0x9')][_0x5730('0xa')][_0x1b9f10][_0x5730('0x9')][_0x5edfb1]['right']&&(document[_0x5730('0x38')](_0x5730('0x11')+_0x1b9f10+_0x5edfb1)[_0x5730('0x2')]='correct'),document[_0x5730('0x38')](_0x5730('0x11')+_0x1b9f10+_0x5edfb1)['checked']?this[_0x5730('0x9')][_0x5730('0xa')][_0x1b9f10][_0x5730('0x9')][_0x5edfb1][_0x5730('0x41')]||(_0x167a84=!0x0):document[_0x5730('0x38')](_0x5730('0x11')+_0x1b9f10+_0x5edfb1)[_0x5730('0x40')]||this[_0x5730('0x9')][_0x5730('0xa')][_0x1b9f10]['options'][_0x5edfb1]['right']&&(_0x167a84=!0x0);
    _0x167a84||this[_0x5730('0x1e')]++;}_0x67946b[_0x5730('0x10')](this,_0x1b9f10);
  }
  this[_0x5730('0x9')][_0x5730('0x33')]&&clearInterval(this[_0x5730('0x44')]);
  var _0x46bbb2=document[_0x5730('0x0')](_0x5730('0x4'));_0x46bbb2[_0x5730('0x6')]=_0x5730('0x45')+this[_0x5730('0x1e')]+'/'+this[_0x5730('0x9')][_0x5730('0xa')][_0x5730('0xf')],this[_0x5730('0x25')][_0x5730('0x7')](_0x46bbb2);
  document.getElementById("mytext").value = _0x46bbb2[_0x5730('0x6')];
};
}());
  var data = [
    {
      "type":"radio","question":"ചൈനയിലെ ഏത് പ്രവിശ്യയിലാണ് പുതിയ കൊറോണ വൈറസ് പൊട്ടിപ്പുറപ്പെട്ടതെന്നു കരുതുന്ന ഹ്വാനൻ മാംസ മാർക്കറ്റ്?","explanation":"","options":[
    {
      "value":"ഹൈനാൻ","right":false,"selected":false},
  {
    "value":"ഹൂബെ","right":true,"selected":false},
  {
    "value":"ബെയ്‌ജിങ്","right":false,"selected":false},
  {
    "value":"ജിയാങ്ഷി","right":false,"selected":false}],"selected":"1"},
  {
    "type":"radio","question":"താഴെപ്പറയുന്നവയിൽ ഏതാണ് പുതിയ കൊറോണ വൈറസ് പരത്തുന്ന രോഗം?","explanation":"","options":[
    {
      "value":"സാർസ് കോവ്–2","right":false,"selected":false},
  {
    "value":"കോവിഡ്–19","right":true,"selected":false},
  {
    "value":"ഹാന്റ പൾമനറി സിൻഡ്രം","right":false,"selected":false},
  {
    "value":"മെർസ്","right":false,"selected":false}],"selected":"1"},
  {
    "type":"radio","question":"കോവിഡ് 19 രോഗം പരത്തുന്ന വൈറസിന്റെ പേര്?","explanation":"","options":[
    {
      "value":"മെർസ്","right":false,"selected":false},
  {
    "value":"എബോള","right":false,"selected":false},
  {
    "value":"സാർസ് കോവ്–2 ","right":true,"selected":false},
  {
    "value":"ഹാന്റ","right":false,"selected":false}],"selected":"2"},
  {
    "type":"radio","question":"ജാവ എന്ന കമ്പ്യൂട്ടർ ഭാഷ കണ്ടു പിടിച്ചത്  ആര്","explanation":"","options":[
    {
      "value":"ജെയിംസ് ഗോസ്ലിഗ്","right":true,"selected":false},
  {
    "value":"ഗൈഡോ  വാൻ  റോസ്സും","right":false,"selected":false},
  {
    "value":"ഡെന്നിസ് റിട്ചീ","right":false,"selected":false},
  {
    "value":"റസ്മോസ് ലേർഡോർഫ്","right":false,"selected":false}],"selected":null},
  {
    "type":"radio","question":"അര്ജന്റീന ഫുട്ബോൾ ഇതിഹാസം ഡീഗോ മറഡോണയുടെ ജന്മ സ്ഥലം?","explanation":"","options":[
    {
      "value":"ലാനുസ്","right":true,"selected":false},
  {
    "value":"സുബോട്ടിക്ക","right":false,"selected":false},
  {
    "value":"ബിജെൽജിന","right":false,"selected":false},
  {
    "value":"ടുസ്‌ല","right":false,"selected":false}],"selected":null},
  {
    "type":"radio","question":"3 + 6 x (5 + 4) ÷ 3 - 7","explanation":"","options":[
    {
      "value":"11","right":false,"selected":false},
  {
    "value":"16","right":false,"selected":false},
  {
    "value":"14","right":true,"selected":false},
  {
    "value":"15","right":false,"selected":false}],"selected":"2"},
  {
    "type":"radio","question":"ഭാവിയുടെ ലോഹം എന്ന് അറിയപ്പെടുന്നത് ലോഹം?","explanation":"","options":[
    {
      "value":"ടൈറ്റാനിയം","right":true,"selected":false},
  {
    "value":"മഗ്‌നഷ്യം","right":false,"selected":false},
  {
    "value":"ഇരിഡിയം","right":false,"selected":false},
  {
    "value":"സ്വർണം","right":false,"selected":false}],"selected":null},
  {
    "type":"radio","question":"ഇന്ത്യൻ അലക്സാണ്ടർ എന്ന് അറിയപ്പെടുന്നത് ആര്?","explanation":"","options":[
    {
      "value":"അക്ബർ","right":false,"selected":false},
  {
    "value":"ഷാജഹാൻ","right":false,"selected":false},
  {
    "value":"അലാവുദ്ധീൻ ഗിൽജി","right":true,"selected":false},
  {
    "value":"അശോകൻ","right":false,"selected":false}],"selected":"2"},
  {
    "type":"radio","question":"ഒരു സംഖ്യയുടെ 30% 120 ആയാൽ സംഖ്യ എത്ര?","explanation":"","options":[
    {
      "value":"400","right":true,"selected":false},
  {
    "value":"360","right":false,"selected":false},
  {
    "value":"396","right":false,"selected":false},
  {
    "value":"410","right":false,"selected":false}],"selected":null},
  {
    "type":"radio","question":"ഒന്നാം പാനിപ്പയറ്റ് യുദ്ധം നടന്നത് എപ്പോൾ?","explanation":"","options":[
    {
      "value":"1506","right":false,"selected":false},
  {
    "value":"1516","right":false,"selected":false},
  {
    "value":"1526","right":true,"selected":false},
  {
    "value":"1536","right":false,"selected":false}],"selected":"2"},
  {
    "type":"radio","question":"നെല്ലിക്കയിൽ ധാരാളം അടങ്ങിയിരിക്കുന്ന ജീവകം  ഏത്?","explanation":"","options":[
    {
      "value":"ജീവകം A","right":false,"selected":false},
  {
    "value":"ജീവകം B","right":false,"selected":false},
  {
    "value":"ജീവകം C","right":true,"selected":false},
  {
    "value":"ജീവകം D","right":false,"selected":false}],"selected":"2"},
  {
    "type":"radio","question":"എടക്കൽ ഗുഹ സ്ഥിതി ചെയ്യുന്നത് കേരളത്തിലെ ഏത് ജില്ലയിലാണ്?","explanation":"","options":[
    {
      "value":"കാസറഗോഡ്","right":false,"selected":false},
  {
    "value":"കണ്ണൂർ","right":false,"selected":false},
  {
    "value":"വയനാട്","right":true,"selected":false},
  {
    "value":"കോഴിക്കോട്","right":false,"selected":false}],"selected":"2"},
  {
    "type":"radio","question":"ജലദോഷത്തിന്റെ ശാസ്ത്ര നാമം?","explanation":"","options":[
    {
      "value":"നാസോഫറിന് ജൈറ്റിസ്","right":true,"selected":false},
  {
    "value":"നാസോഫറിൻ ബ്ലെൻഡ്","right":false,"selected":false},
  {
    "value":"ഇൻസോംനിയ","right":false,"selected":false},
  {
    "value":"എഫിസിയാ","right":false,"selected":false}],"selected":null},
  {
    "type":"radio","question":"ഇന്റർനെറ്റ്‌ ഉപയോഗത്തിനായി ആദ്യം ഉപയോഗിച്ച ഭാഷ?","explanation":"","options":[
    {
      "value":"സി ഷാർപ്","right":false,"selected":false},
  {
    "value":"ബേസിക്","right":false,"selected":false},
  {
    "value":"കോബോൾ","right":false,"selected":false},
  {
    "value":"ജാവ","right":true,"selected":false}],"selected":"3"},
  {
    "type":"radio","question":"ചാട്ടം എന്ന പദം ഏത് വിഭാഗത്തിൽ പെടുന്നു?","explanation":"","options":[
    {
      "value":"ഗുണനാമം","right":false,"selected":false},
  {
    "value":"ക്രിയനാമം","right":true,"selected":false},
  {
    "value":"മേയനാമം","right":false,"selected":false},
  {
    "value":"സർവ്വനാമം","right":false,"selected":false}],"selected":"1"},
  {
    "type":"radio","question":"ഏഷ്യയിൽ ആദ്യ യുദ്ധക്കപ്പൽ രൂപനാകല്പന കേന്ദ്രത്തിന് 2011 ജനുവരി 4 ന്  തറക്കല്ലിട്ടത് എവിടെ?","explanation":"","options":[
    {
      "value":"കേരളം","right":true,"selected":false},
  {
    "value":"ഉത്തർപ്രദേശ്","right":false,"selected":false},
  {
    "value":"ഗോവ","right":false,"selected":false},
  {
    "value":"തമിഴ്നാട്","right":false,"selected":false}],"selected":null},
  {
    "type":"radio","question":"മനുഷ്യ ശരീരത്തിൽ യൂറിയ ഉത്പാധിപ്പിക്കുന്ന അവയവം?","explanation":"","options":[
    {
      "value":"കരൾ","right":true,"selected":false},
  {
    "value":"ഹൃദയം","right":false,"selected":false},
  {
    "value":"വൃക്ക","right":false,"selected":false},
  {
    "value":"പ്ലീഹ","right":false,"selected":false}],"selected":null},
  {
    "type":"radio","question":"ബർമുഡ ട്രയാങ്കിൾ സ്ഥിതി ചെയ്യുന്ന സാമുദ്രം ?","explanation":"","options":[
    {
      "value":"അറ്റ്ലാന്റിക്","right":false,"selected":false},
  {
    "value":"പേസ്ഫിക്","right":true,"selected":false},
  {
    "value":"ആർട്ടിക്","right":false,"selected":false},
  {
    "value":"ഇന്ത്യൻ","right":false,"selected":false}],"selected":"1"},
  {
    "type":"radio","question":"ജോ ബിഡൻ അമേരിക്കയുടെ എത്രാമത്തെ പ്രസിഡന്ടാണ് ?","explanation":"","options":[
    {
      "value":"38","right":false,"selected":false},
  {
    "value":"46","right":true,"selected":false},
  {
    "value":"48","right":false,"selected":false},
  {
    "value":"48","right":false,"selected":false}],"selected":"1"},
  {
    "type":"radio","question":"തിരഞ്ഞെടുപ്പ് ഹരജി തീരുമാനിക്കാനുള്ള അധികാരം ആർക്ക്?","explanation":"","options":[
    {
      "value":"പാർലിമെന്റ്","right":false,"selected":false},
  {
    "value":"സുപ്രീം കോർട്ട്","right":false,"selected":false},
  {
    "value":"ഹൈ കോർട്ട്","right":true,"selected":false},
  {
    "value":"ഇലക്ഷന്കമ്മീഷൻ","right":false,"selected":false}],"selected":"2"},
  {
    "type":"radio","question":"ലോക്സഭയിലേക്കുള്ള തിരഞ്ഞെടുപ്പിന് യോഗ്യത നേടുന്നതിനുള്ള ഏറ്റവും കുറഞ്ഞ പ്രായം?","explanation":"","options":[
    {
      "value":"18","right":false,"selected":false},
  {
    "value":"21","right":false,"selected":false},
  {
    "value":"25","right":true,"selected":false},
  {
    "value":"35","right":false,"selected":false}],"selected":"2"},
  {
    "type":"radio","question":"\"ആയേൺ\"എന്ന വാക്ക് ഏത് കളിയുമായി ബന്ധപ്പെട്ടതാണ്?","explanation":"","options":[
    {
      "value":"ബേസ്ബാൾ","right":false,"selected":false},
  {
    "value":"ഗോൾഫ്","right":true,"selected":false},
  {
    "value":"ക്രിക്കറ്റ്‌","right":false,"selected":false},
  {
    "value":"ബില്ലിയാർഡ്‌സ്","right":false,"selected":false}],"selected":"1"},
  {
    "type":"radio","question":"ഗാന്ധിജയുടെ അമ്മയുടെ പേര് എന്തായിരുന്നു?","explanation":"","options":[
    {
      "value":"ജീജാ ബായി","right":false,"selected":false},
  {
    "value":"രമാ ബായി","right":false,"selected":false},
  {
    "value":"സന്താമായി","right":false,"selected":false},
  {
    "value":"പുത് ലി ബായി","right":true,"selected":false}],"selected":"3"},
  {
    "type":"radio","question":"പേസ്ഫിക് സാമുദ്രം ഒറ്റയ്ക്ക് തുഴഞ്ഞു റെക്കോർഡ് നേടിയ വനിത?","explanation":"","options":[
    {
      "value":"റോസ് സാവേജ്","right":true,"selected":false},
  {
    "value":"ബ്രിട്നി സ്പിയേഴ്‌സ്","right":false,"selected":false},
  {
    "value":"മാർഗരറ്റ് ചാൻ","right":false,"selected":false},
  {
    "value":"ഇവരാരുമല്ല","right":false,"selected":false}],"selected":null},
  {
    "type":"radio","question":"സസ്യങ്ങൾ രാത്രി സമയത്ത് പുറത്ത് വിടുന്ന വാതകം.?","explanation":"","options":[
    {
      "value":"ഓക്സിജൻ","right":false,"selected":false},
  {
    "value":"കാർബൺ ഡായോക്സയ്ഡ്","right":true,"selected":false},
  {
    "value":"നൈട്രജൻ","right":false,"selected":false},
  {
    "value":"ഹൈഡ്രജൻ","right":false,"selected":false}],"selected":"1"},
  {
    "type":"radio","question":"പ്രാപഞ്ചത്തിൽ ഏറ്റവും കൂടുതൽ ഉള്ള വാതകം?","explanation":"","options":[
    {
      "value":"ഹീലിയം","right":false,"selected":false},
  {
    "value":"നൈട്രജൻ","right":false,"selected":false},
  {
    "value":"ഓക്സിജൻ","right":false,"selected":false},
  {
    "value":"ഹൈഡ്രജൻ","right":true,"selected":false}],"selected":"3"},
  {
    "type":"radio","question":"ഫാരൻഹീറ്റിലെ ഏത് താപനിലയിലാണ് വെള്ളം തിളയ്ക്കുന്നത്?","explanation":"","options":[
    {
      "value":"100 ഡിഗ്രീസ്","right":false,"selected":false},
  {
    "value":"212 ഡിഗ്രീസ്","right":true,"selected":false},
  {
    "value":"253 ഡിഗ്രീസ്","right":false,"selected":false},
  {
    "value":"312 ഡിഗ്രീസ്","right":false,"selected":false}],"selected":"1"},
  {
    "type":"radio","question":"ക്ലൈഡെസ്‌ഡേൽ ഏത് തരം മൃഗമാണ് ?","explanation":"","options":[
    {
      "value":"കുതിര","right":true,"selected":false},
  {
    "value":"പന്നി","right":false,"selected":false},
  {
    "value":"നായ","right":false,"selected":false},
  {
    "value":"പശു","right":false,"selected":false}],"selected":null},
  {
    "type":"radio","question":"മനുഷ്യർ സഞ്ചരിച്ച ഭൂമിയിൽ നിന്ന് ഏറ്റവും ദൂരം 400,000 കിലോമീറ്റർ ദൂരെയാണ് ബഹിരാകാശയാത്രികരായ ഹെയ്സ്, ലവൽ, സ്വിഗെർട്ട്, പക്ഷേ ദൗത്യത്തിന്റെ പേരെന്താണ് ?","explanation":"","options":[
    {
      "value":"അപ്പൊളൊ 7","right":false,"selected":false},
  {
    "value":"അപ്പൊളൊ 9","right":false,"selected":false},
  {
    "value":"അപ്പൊളൊ 11","right":false,"selected":false},
  {
    "value":"അപ്പൊളൊ 13","right":true,"selected":false}],"selected":"3"},
  {
    "type":"radio","question":"1609 ൽ ഗലീലിയോ കണ്ടെത്തിയ ഗലീലിയൻ ഉപഗ്രഹങ്ങൾ ഏത് ഗ്രഹത്തെ പരിക്രമണം ചെയ്യുന്നു ?","explanation":"","options":[
    {
      "value":"ശനി","right":false,"selected":false},
  {
    "value":"യുറാനസ്","right":false,"selected":false},
  {
    "value":"ചൊവ്വ","right":false,"selected":false},
  {
    "value":"വ്യാഴം","right":true,"selected":false}],"selected":"3"},
  {
    "type":"radio","question":"ഒരു ആഫ്രിക്കൻ കാണ്ടാമൃഗത്തിന് എത്ര കൊമ്പുകളുണ്ട് ?","explanation":"","options":[
    {
      "value":"ഒന്ന്","right":false,"selected":false},
  {
    "value":"രണ്ട്","right":true,"selected":false},
  {
    "value":"മൂന്ന്","right":false,"selected":false},
  {
    "value":"ഒന്നുമില്ല","right":false,"selected":false}],"selected":"1"},
  {
    "type":"radio","question":"രാത്രി ആകാശത്ത് \"ഹാലി കോമറ്റ്\" അവസാനമായി പ്രത്യക്ഷപ്പെട്ടത് എപ്പോഴാണ്?","explanation":"","options":[
    {
      "value":"1900","right":false,"selected":false},
  {
    "value":"1945","right":false,"selected":false},
  {
    "value":"1986","right":true,"selected":false},
  {
    "value":"2005","right":false,"selected":false}],"selected":"2"}];

var quiz = new Quiz(
  {
        quizQuestions: data,elementId: 'quiz_container',showAllQuestions:false,showTimer:false
  });